import cv2
import numpy as np
import os
from deepface import DeepFace
from datetime import datetime

# ── Setup ─────────────────────────────────────────────────────────
DATASET_PATH = 'ImagesAttendance'
CSV_FILE = 'Attendance.csv'

if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, 'w') as f:
        f.write('Name,Time\n')

# ── Variabel global untuk info absen ─────────────────────────────
absen_info = ""

# ── Fungsi catat absen ────────────────────────────────────────────
def markAttendance(name):
    global absen_info
    with open(CSV_FILE, 'r+') as f:
        lines = f.readlines()
        names = [line.split(',')[0] for line in lines]
        if name not in names:
            now = datetime.now().strftime('%H:%M:%S')
            f.write(f'{name},{now}\n')
            absen_info = f"{name} absen pukul {now}"
            print(f"✅ {absen_info}")
        else:
            absen_info = f"{name} sudah absen hari ini"

# ── Buka kamera ───────────────────────────────────────────────────
cap = cv2.VideoCapture(0)
print("Kamera aktif! Tekan 'q' untuk keluar.")

name_display = "Detecting..."
color = (255, 255, 0)
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
frame_count = 0

while True:
    success, img = cap.read()
    if not success:
        break

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    frame_count += 1
    if frame_count % 30 == 0:
        try:
            result = DeepFace.find(
                img_path=img,
                db_path=DATASET_PATH,
                enforce_detection=False,
                silent=True
            )
            if len(result) > 0 and not result[0].empty:
                filepath = result[0].iloc[0]['identity']
                name_display = os.path.splitext(os.path.basename(filepath))[0].upper()
                color = (0, 255, 0)
                markAttendance(name_display)
            else:
                name_display = "UNKNOWN"
                color = (0, 0, 255)
                absen_info = ""
        except:
            name_display = "Detecting..."
            color = (255, 255, 0)

    # Gambar kotak wajah
    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x+w, y+h), color, 2)
        cv2.rectangle(img, (x, y+h-35), (x+w, y+h), color, cv2.FILLED)
        cv2.putText(img, name_display, (x+6, y+h-6),
                    cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 2)

    # ── Info absen di pojok kiri bawah ────────────────────────────
    h_img = img.shape[0]
    if absen_info:
        cv2.rectangle(img, (0, h_img-50), (500, h_img), (0, 0, 0), cv2.FILLED)
        cv2.putText(img, absen_info, (10, h_img-15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    # Jam realtime pojok kanan atas
    now_str = datetime.now().strftime('%H:%M:%S')
    cv2.putText(img, now_str, (img.shape[1]-120, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    cv2.putText(img, "Press 'q' to quit", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)

    cv2.imshow('Face Attendance System', img)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()