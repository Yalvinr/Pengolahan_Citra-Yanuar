import traceback
import sys

try:
    print("Python path:", sys.executable)
    print("Attempting to import face_recognition...")
    import face_recognition
    print("✅ face_recognition imported successfully!")
except Exception as e:
    print("❌ Error importing face_recognition:")
    print(f"Error message: {e}")
    print("\nFull traceback:")
    traceback.print_exc()
