call conda activate faceattend
python attendance.py
pause